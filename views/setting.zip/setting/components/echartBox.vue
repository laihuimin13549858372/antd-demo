<template>
  <div>
    <span style="float:left">{{title}}</span>
    <div style="float:right">明细</div>
    <div>
      <slot name="filterCriteria"></slot>
      <echart2 ref="echart2" :dataList="dataList"
               :id="id"></echart2>
    </div>

  </div>
</template>

<script>
import echart2 from './echart2'
export default {
  components: {
    echart2,
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    dataList: {
      type: Array,
      default: () => {
        return []
      },
    },
    id: {
      type: String,
    }
  },

  name: 'echartBox',
  data () {
    return {

    };
  },
  methods: {
    //初始化中国地图

  },
  created () {

  },
  mounted () {


  }
};
</script>

<style scoped>
#china_map_box {
  height: 100%;
  position: relative;
}
#china_map_box #china_map {
  height: 100%;
}
#china_map_box .china_map_logo {
  position: absolute;
  top: 0;
  left: 0;
  width: 45px;
}
</style>