<template>
  <div id="main"
       style="width:100%;height:100%">
    <button @click="dian()">点击改变</button>
    <a-card style="width:100%;height:100%">
      <a-row :gutter='[15,5]'
             style="height:100%;width:100%">
        <a-col :span="12"
               class="h33">
          <echartBox title="投票业务"
                     ref="firstEchart"
                     id="firstEchart"
                     :dataList="dataList1">
            <!-- <div slot="filterCriteria">
              <v-filter></v-filter>
            </div> -->
          </echartBox>
        </a-col>
        <a-col :span="12"
               class="h33">
          <echartBox title="投票业务"
                     ref="secondEchart"
                     id="secondEchart"
                     :dataList="dataList2">
            <!-- <div slot="filterCriteria">
              <v-filter></v-filter>
            </div> -->
          </echartBox>
        </a-col>

      </a-row>
    </a-card>

  </div>
</template>

<script>
import echartBox from './components/echartBox'
export default {
  components: {
    echartBox,
  },
  data () {
    return {
      dataList1: [
        { name: "南海诸岛", value: 0 },
        { name: '北京', value: Math.round(Math.random() * 1000) },
        { name: '天津', value: Math.round(Math.random() * 1000) },
        { name: '上海', value: Math.round(Math.random() * 1000) },
        { name: '重庆', value: Math.round(Math.random() * 1000) },
        { name: '河北', value: Math.round(Math.random() * 1000) },
        { name: '河南', value: Math.round(Math.random() * 1000) },
        { name: '云南', value: Math.round(Math.random() * 1000) },
        { name: '辽宁', value: Math.round(Math.random() * 1000) },
        { name: '黑龙江', value: Math.round(Math.random() * 1000) },
        { name: '湖南', value: Math.round(Math.random() * 1000) },
        { name: '安徽', value: Math.round(Math.random() * 1000) },
        { name: '山东', value: Math.round(Math.random() * 1000) },
        { name: '新疆', value: Math.round(Math.random() * 1000) },
        { name: '江苏', value: Math.round(Math.random() * 1000) },
        { name: '浙江', value: Math.round(Math.random() * 1000) },
        { name: '江西', value: Math.round(Math.random() * 1000) },
        { name: '湖北', value: Math.round(Math.random() * 1000) },
        { name: '广西', value: Math.round(Math.random() * 1000) },
        { name: '甘肃', value: Math.round(Math.random() * 1000) },
        { name: '山西', value: Math.round(Math.random() * 1000) },
        { name: '内蒙古', value: Math.round(Math.random() * 1000) },
        { name: '陕西', value: Math.round(Math.random() * 1000) },
        { name: '吉林', value: Math.round(Math.random() * 1000) },
        { name: '福建', value: Math.round(Math.random() * 1000) },
        { name: '贵州', value: Math.round(Math.random() * 1000) },
        { name: '广东', value: Math.round(Math.random() * 1000) },
        { name: '青海', value: Math.round(Math.random() * 1000) },
        { name: '西藏', value: Math.round(Math.random() * 1000) },
        { name: '四川', value: Math.round(Math.random() * 1000) },
        { name: '宁夏', value: Math.round(Math.random() * 1000) },
        { name: '海南', value: Math.round(Math.random() * 1000) },
        { name: '台湾', value: Math.round(Math.random() * 1000) },
        { name: '香港', value: Math.round(Math.random() * 1000) },
        { name: '澳门', value: Math.round(Math.random() * 1000) }
      ],
      dataList2: [
        { name: "南海诸岛", value: 0 },
        { name: '北京', value: Math.round(Math.random() * 1000) },
        { name: '天津', value: Math.round(Math.random() * 1000) },
        { name: '上海', value: Math.round(Math.random() * 1000) },
        { name: '重庆', value: Math.round(Math.random() * 1000) },
        { name: '河北', value: Math.round(Math.random() * 1000) },
        { name: '河南', value: Math.round(Math.random() * 1000) },
        { name: '云南', value: Math.round(Math.random() * 1000) },
        { name: '辽宁', value: Math.round(Math.random() * 1000) },
        { name: '黑龙江', value: Math.round(Math.random() * 1000) },
        { name: '湖南', value: Math.round(Math.random() * 1000) },
        { name: '安徽', value: Math.round(Math.random() * 1000) },
        { name: '山东', value: Math.round(Math.random() * 1000) },
        { name: '新疆', value: Math.round(Math.random() * 1000) },
        { name: '江苏', value: Math.round(Math.random() * 1000) },
        { name: '浙江', value: Math.round(Math.random() * 1000) },
        { name: '江西', value: Math.round(Math.random() * 1000) },
        { name: '湖北', value: Math.round(Math.random() * 1000) },
        { name: '广西', value: Math.round(Math.random() * 1000) },
        { name: '甘肃', value: Math.round(Math.random() * 1000) },
        { name: '山西', value: Math.round(Math.random() * 1000) },
        { name: '内蒙古', value: Math.round(Math.random() * 1000) },
        { name: '陕西', value: Math.round(Math.random() * 1000) },
        { name: '吉林', value: Math.round(Math.random() * 1000) },
        { name: '福建', value: Math.round(Math.random() * 1000) },
        { name: '贵州', value: Math.round(Math.random() * 1000) },
        { name: '广东', value: Math.round(Math.random() * 1000) },
        { name: '青海', value: Math.round(Math.random() * 1000) },
        { name: '西藏', value: Math.round(Math.random() * 1000) },
        { name: '四川', value: Math.round(Math.random() * 1000) },
        { name: '宁夏', value: Math.round(Math.random() * 1000) },
        { name: '海南', value: Math.round(Math.random() * 1000) },
        { name: '台湾', value: Math.round(Math.random() * 1000) },
        { name: '香港', value: Math.round(Math.random() * 1000) },
        { name: '澳门', value: Math.round(Math.random() * 1000) }
      ]

    };
  },
  methods: {
    dian () {
      console.log('进入这里', this.$refs.firstEchart.$refs.echart2)
      const context = this;
      setTimeout(function () {
        context.dataList2 = [];
        context.dataList2 = [
          { name: "南海诸岛", value: 0 },
          { name: '北京', value: Math.round(Math.random() * 1000) },
          { name: '天津', value: Math.round(Math.random() * 1000) },
          { name: '上海', value: Math.round(Math.random() * 1000) },
          { name: '重庆', value: Math.round(Math.random() * 1000) },
          { name: '河北', value: Math.round(Math.random() * 1000) },
          { name: '河南', value: Math.round(Math.random() * 1000) },
          { name: '云南', value: Math.round(Math.random() * 1000) },
          { name: '辽宁', value: Math.round(Math.random() * 1000) },
          { name: '黑龙江', value: Math.round(Math.random() * 1000) },
          { name: '湖南', value: Math.round(Math.random() * 1000) },
          { name: '安徽', value: Math.round(Math.random() * 1000) },
          { name: '山东', value: Math.round(Math.random() * 1000) },
          { name: '新疆', value: Math.round(Math.random() * 1000) },
          { name: '江苏', value: Math.round(Math.random() * 1000) },
          { name: '浙江', value: Math.round(Math.random() * 1000) },
          { name: '江西', value: Math.round(Math.random() * 1000) },
          { name: '湖北', value: Math.round(Math.random() * 1000) },
          { name: '广西', value: Math.round(Math.random() * 1000) },
          { name: '甘肃', value: Math.round(Math.random() * 1000) },
          { name: '山西', value: Math.round(Math.random() * 1000) },
          { name: '内蒙古', value: Math.round(Math.random() * 1000) },
          { name: '陕西', value: Math.round(Math.random() * 1000) },
          { name: '吉林', value: Math.round(Math.random() * 1000) },
          { name: '福建', value: Math.round(Math.random() * 1000) },
          { name: '贵州', value: Math.round(Math.random() * 1000) },
          { name: '广东', value: Math.round(Math.random() * 1000) },
          { name: '青海', value: Math.round(Math.random() * 1000) },
          { name: '西藏', value: Math.round(Math.random() * 1000) },
          { name: '四川', value: Math.round(Math.random() * 1000) },
          { name: '宁夏', value: Math.round(Math.random() * 1000) },
          { name: '海南', value: Math.round(Math.random() * 1000) },
          { name: '台湾', value: Math.round(Math.random() * 1000) },
          { name: '香港', value: Math.round(Math.random() * 1000) },
          { name: '澳门', value: Math.round(Math.random() * 1000) }
        ]
        context.dataList1 = [];
        context.dataList1 = [
          { name: "南海诸岛", value: 0 },
          { name: '北京', value: Math.round(Math.random() * 1000) },
          { name: '天津', value: Math.round(Math.random() * 1000) },
          { name: '上海', value: Math.round(Math.random() * 1000) },
          { name: '重庆', value: Math.round(Math.random() * 1000) },
          { name: '河北', value: Math.round(Math.random() * 1000) },
          { name: '河南', value: Math.round(Math.random() * 1000) },
          { name: '云南', value: Math.round(Math.random() * 1000) },
          { name: '辽宁', value: Math.round(Math.random() * 1000) },
          { name: '黑龙江', value: Math.round(Math.random() * 1000) },
          { name: '湖南', value: Math.round(Math.random() * 1000) },
          { name: '安徽', value: Math.round(Math.random() * 1000) },
          { name: '山东', value: Math.round(Math.random() * 1000) },
          { name: '新疆', value: Math.round(Math.random() * 1000) },
          { name: '江苏', value: Math.round(Math.random() * 1000) },
          { name: '浙江', value: Math.round(Math.random() * 1000) },
          { name: '江西', value: Math.round(Math.random() * 1000) },
          { name: '湖北', value: Math.round(Math.random() * 1000) },
          { name: '广西', value: Math.round(Math.random() * 1000) },
          { name: '甘肃', value: Math.round(Math.random() * 1000) },
          { name: '山西', value: Math.round(Math.random() * 1000) },
          { name: '内蒙古', value: Math.round(Math.random() * 1000) },
          { name: '陕西', value: Math.round(Math.random() * 1000) },
          { name: '吉林', value: Math.round(Math.random() * 1000) },
          { name: '福建', value: Math.round(Math.random() * 1000) },
          { name: '贵州', value: Math.round(Math.random() * 1000) },
          { name: '广东', value: Math.round(Math.random() * 1000) },
          { name: '青海', value: Math.round(Math.random() * 1000) },
          { name: '西藏', value: Math.round(Math.random() * 1000) },
          { name: '四川', value: Math.round(Math.random() * 1000) },
          { name: '宁夏', value: Math.round(Math.random() * 1000) },
          { name: '海南', value: Math.round(Math.random() * 1000) },
          { name: '台湾', value: Math.round(Math.random() * 1000) },
          { name: '香港', value: Math.round(Math.random() * 1000) },
          { name: '澳门', value: Math.round(Math.random() * 1000) }
        ]
        console.log(context.dataList1)
      }, 2000)
    }
  },
  created () {

  },
  mounted () {
    console.log(this.dataList)


  }
};
</script>

<style scoped>
#china_map_box {
  height: 100%;
  position: relative;
}
#china_map_box #china_map {
  height: 100%;
}
#china_map_box .china_map_logo {
  position: absolute;
  top: 0;
  left: 0;
  width: 45px;
}
::v-deep .ant-card-body {
  width: 100%;
  height: 100%;
}
.h33 {
  height: 33%;
}
</style>